﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;

namespace TaskManagement
{
    public partial class _Default : Page
    {
        static string conString = ConfigurationManager.ConnectionStrings["dbcon"].ToString();
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    SqlCommand cmd = new SqlCommand("select  * from Users where username = @username and password = @password", con);
                    cmd.Parameters.AddWithValue("@username", txtUserName.Text);
                    cmd.Parameters.AddWithValue("password", txtPassword.Text);
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    con.Open();
                    int i = cmd.ExecuteNonQuery();
                    con.Close();

                    if (dt.Rows.Count > 0)
                    {
                        Response.Redirect("DashBoard.aspx");
                    }
                    else
                    {
                        Label1.Text = "You're username and password is incorrect";
                        Label1.ForeColor = System.Drawing.Color.Red;

                    }
                }
                
            }
            catch (Exception)
            {
                throw;
            }
            


        }
    }
}