﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TaskManagement
{
    public partial class DashBoard : System.Web.UI.Page
    {
        static string conString = ConfigurationManager.ConnectionStrings["dbcon"].ToString();
        string currentUser = "admin";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                ShowData();
            }
        }
        protected void ShowData()
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                SqlCommand cmd = new SqlCommand("select TaskID, UserUniqueID, Description, DueDate, Priority, Status from users u inner join tasks t on u.UniqueID = t.UserUniqueID where UserName = @username", con);
                cmd.Parameters.AddWithValue("@username", currentUser);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    gvTasks.DataSource = dt;
                    gvTasks.DataBind();
                }
            }
        }
        protected void gvTasks_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gvTasks.EditIndex = e.NewEditIndex;
            ShowData();
        }
        protected void gvTasks_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gvTasks.EditIndex = -1;
            ShowData();
        }

        protected void gvTasks_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                int id = Convert.ToInt16(gvTasks.DataKeys[e.RowIndex].Values["TaskID"].ToString());
                SqlCommand cmd = new SqlCommand("delete from Tasks where TaskID = @id", con);
                cmd.Parameters.AddWithValue("@id", id);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                ShowData();
            }

        }

        protected void gvTasks_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && (e.Row.RowState & DataControlRowState.Edit) == DataControlRowState.Edit)
            {
                DropDownList ddlStatus = (e.Row.FindControl("ddlStatus") as DropDownList);
                string country = (e.Row.FindControl("lblStatus") as Label).Text;
                ddlStatus.Items.Insert(0, new ListItem("Please select"));
                ddlStatus.Items.FindByValue(country).Selected = true;
            }
        }

        protected void gvTasks_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            Label id = gvTasks.Rows[e.RowIndex].FindControl("TaskID") as Label;
            DropDownList ddlStatus = gvTasks.Rows[e.RowIndex].FindControl("ddlStatus") as DropDownList;

            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Update Tasks set Status='" + ddlStatus.SelectedItem.Text + "' where TaskID=" + Convert.ToInt32(id.Text), con);
                cmd.ExecuteNonQuery();
                con.Close();
                gvTasks.EditIndex = -1;
                ShowData();
            }

        }
    }
}